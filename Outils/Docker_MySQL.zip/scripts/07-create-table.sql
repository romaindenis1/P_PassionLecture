-- Dans la base de données db_book, créez la table t_book, avec ...
--       une colonne booTitre de type varchar(50) , 
--       une colonne booAuteur de type varchar(40) , 

-- (remplacer ce commentaire par la commande SQL adéquate)